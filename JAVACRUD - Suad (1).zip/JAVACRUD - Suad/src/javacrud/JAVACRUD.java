package javacrud;


public class JAVACRUD {

    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
